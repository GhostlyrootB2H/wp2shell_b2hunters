"""wp2shell GUI – tkinter interface. Calls wp2shell.py / wp2shell_scan.py / wp2shell_deploy.py via subprocess."""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WP2SHELL = os.path.join(BASE_DIR, "wp2shell.py")
WP2SHELL_SCAN = os.path.join(BASE_DIR, "wp2shell_scan.py")
WP2SHELL_DEPLOY = os.path.join(BASE_DIR, "wp2shell_deploy.py")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("wp2shell GUI")
        self.geometry("820x670")
        self.minsize(640, 500)
        self.configure(bg="#1e1e2e")
        self._proc: subprocess.Popen | None = None
        self._build()

    def _build(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TLabel", background="#1e1e2e", foreground="#cdd6f4", font=("Consolas", 10))
        s.configure("TEntry", font=("Consolas", 10))
        s.configure("TCheckbutton", background="#1e1e2e", foreground="#cdd6f4", font=("Consolas", 10))
        s.configure("TButton", font=("Consolas", 10))
        s.configure("TNotebook", background="#1e1e2e")
        s.configure("TNotebook.Tab", font=("Consolas", 10, "bold"), padding=[12, 4])
        s.configure("Run.TButton", font=("Consolas", 11, "bold"))
        s.configure("Stop.TButton", font=("Consolas", 11, "bold"))

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=(8, 0))

        self.tab_single = ttk.Frame(notebook)
        notebook.add(self.tab_single, text="  Single Target  ")
        self._build_single(self.tab_single)

        self.tab_mass = ttk.Frame(notebook)
        notebook.add(self.tab_mass, text="  Mass Scan  ")
        self._build_mass(self.tab_mass)

        self.tab_deploy = ttk.Frame(notebook)
        notebook.add(self.tab_deploy, text="  Mass Deploy  ")
        self._build_deploy(self.tab_deploy)

        f_btn = tk.Frame(self, bg="#1e1e2e")
        f_btn.pack(fill="x", padx=10, pady=5)
        self.run_btn = ttk.Button(f_btn, text="  Run  ", style="Run.TButton", command=self._run)
        self.run_btn.pack(side="left", padx=5)
        self.stop_btn = ttk.Button(f_btn, text="  Stop  ", style="Stop.TButton", command=self._stop, state="disabled")
        self.stop_btn.pack(side="left", padx=5)
        ttk.Button(f_btn, text="Clear", command=self._clear_log).pack(side="right", padx=5)

        f_log = ttk.LabelFrame(self, text="Output")
        f_log.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        self.log = tk.Text(f_log, bg="#11111b", fg="#cdd6f4", insertbackground="#cdd6f4",
                           font=("Consolas", 9), wrap="word", state="disabled")
        sb = ttk.Scrollbar(f_log, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log.pack(fill="both", expand=True)

    # ── Single target tab ─────────────────────────────────────────────
    def _build_single(self, parent):
        f = tk.Frame(parent, bg="#1e1e2e")
        f.pack(fill="x", padx=10, pady=8)

        r = 0
        ttk.Label(f, text="URL:").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.s_url = tk.StringVar()
        ttk.Entry(f, textvariable=self.s_url, width=55).grid(row=r, column=1, columnspan=3, sticky="ew", padx=4, pady=3)

        r += 1
        ttk.Label(f, text="PHP file:").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.s_php = tk.StringVar()
        ttk.Entry(f, textvariable=self.s_php, width=45).grid(row=r, column=1, sticky="ew", padx=4, pady=3)
        ttk.Button(f, text="Browse\u2026", command=lambda: self._browse_file(self.s_php, "PHP", "*.php")).grid(row=r, column=2, padx=4)

        r += 1
        ttk.Label(f, text="Plugin name:").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.s_plugin = tk.StringVar()
        ttk.Entry(f, textvariable=self.s_plugin, width=30).grid(row=r, column=1, sticky="w", padx=4, pady=3)
        ttk.Label(f, text="(optional, default: wp2custom_<hex>)").grid(row=r, column=2, sticky="w", padx=4)

        r += 1
        ttk.Label(f, text="Command:").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.s_cmd = tk.StringVar(value="id")
        ttk.Entry(f, textvariable=self.s_cmd, width=30).grid(row=r, column=1, sticky="w", padx=4, pady=3)

        r += 1
        self.s_rce = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="--rce (run command after deploy)", variable=self.s_rce).grid(row=r, column=1, sticky="w", padx=4, pady=3)

        r += 1
        self.s_interactive = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="-i (interactive shell)", variable=self.s_interactive).grid(row=r, column=1, sticky="w", padx=4, pady=3)

        f.columnconfigure(1, weight=1)

    # ── Mass scan tab ─────────────────────────────────────────────────
    def _build_mass(self, parent):
        f = tk.Frame(parent, bg="#1e1e2e")
        f.pack(fill="x", padx=10, pady=8)

        r = 0
        ttk.Label(f, text="Target list (.txt):").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.m_list = tk.StringVar()
        ttk.Entry(f, textvariable=self.m_list, width=50).grid(row=r, column=1, sticky="ew", padx=4, pady=3)
        ttk.Button(f, text="Browse\u2026", command=lambda: self._browse_file(self.m_list, "Text", "*.txt")).grid(row=r, column=2, padx=4)

        r += 1
        ttk.Label(f, text="Single URL (alt):").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.m_url = tk.StringVar()
        ttk.Entry(f, textvariable=self.m_url, width=55).grid(row=r, column=1, columnspan=2, sticky="ew", padx=4, pady=3)

        r += 1
        self.m_autodetect = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="-D  Auto-detect HTTPS", variable=self.m_autodetect).grid(row=r, column=1, sticky="w", padx=4, pady=3)

        r += 1
        f2 = tk.Frame(f, bg="#1e1e2e")
        f2.grid(row=r, column=0, columnspan=3, sticky="w", padx=4, pady=3)
        self.m_rce = tk.BooleanVar(value=False)
        ttk.Checkbutton(f2, text="--rce", variable=self.m_rce).pack(side="left", padx=(0, 12))
        ttk.Label(f2, text="Threads:").pack(side="left", padx=(0, 4))
        self.m_threads = tk.StringVar(value="10")
        ttk.Entry(f2, textvariable=self.m_threads, width=5).pack(side="left", padx=(0, 12))
        ttk.Label(f2, text="Timeout:").pack(side="left", padx=(0, 4))
        self.m_timeout = tk.StringVar(value="120")
        ttk.Entry(f2, textvariable=self.m_timeout, width=6).pack(side="left")

        r += 1
        f3 = tk.Frame(f, bg="#1e1e2e")
        f3.grid(row=r, column=0, columnspan=3, sticky="w", padx=4, pady=3)
        self.m_upload = tk.BooleanVar(value=False)
        ttk.Checkbutton(f3, text="Upload PHP:", variable=self.m_upload, command=self._toggle_mass_upload).pack(side="left", padx=(0, 4))
        self.m_php = tk.StringVar()
        self.m_php_entry = ttk.Entry(f3, textvariable=self.m_php, width=35, state="disabled")
        self.m_php_entry.pack(side="left", padx=(0, 4))
        self.m_php_btn = ttk.Button(f3, text="Browse\u2026", state="disabled",
                                    command=lambda: self._browse_file(self.m_php, "PHP", "*.php"))
        self.m_php_btn.pack(side="left", padx=(0, 8))
        ttk.Label(f3, text="Name:").pack(side="left")
        self.m_plugin = tk.StringVar()
        self.m_plugin_entry = ttk.Entry(f3, textvariable=self.m_plugin, width=20, state="disabled")
        self.m_plugin_entry.pack(side="left", padx=4)

        r += 1
        self.m_verbose = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="-v  Verbose", variable=self.m_verbose).grid(row=r, column=1, sticky="w", padx=4, pady=3)

        f.columnconfigure(1, weight=1)

    def _toggle_mass_upload(self):
        state = "normal" if self.m_upload.get() else "disabled"
        self.m_php_entry.configure(state=state)
        self.m_php_btn.configure(state=state)
        self.m_plugin_entry.configure(state=state)

    # ── Mass deploy tab ───────────────────────────────────────────────
    def _build_deploy(self, parent):
        f = tk.Frame(parent, bg="#1e1e2e")
        f.pack(fill="x", padx=10, pady=8)

        ttk.Label(f, text="Confirmed vuln targets:", font=("Consolas", 10, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", padx=4, pady=(3, 6))

        r = 1
        ttk.Label(f, text="Target list (.txt):").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.d_list = tk.StringVar()
        ttk.Entry(f, textvariable=self.d_list, width=50).grid(row=r, column=1, sticky="ew", padx=4, pady=3)
        ttk.Button(f, text="Browse\u2026", command=lambda: self._browse_file(self.d_list, "Text", "*.txt")).grid(row=r, column=2, padx=4)

        r += 1
        ttk.Label(f, text="PHP file:").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.d_php = tk.StringVar()
        ttk.Entry(f, textvariable=self.d_php, width=45).grid(row=r, column=1, sticky="ew", padx=4, pady=3)
        ttk.Button(f, text="Browse\u2026", command=lambda: self._browse_file(self.d_php, "PHP", "*.php")).grid(row=r, column=2, padx=4)

        r += 1
        ttk.Label(f, text="Plugin name:").grid(row=r, column=0, sticky="w", padx=4, pady=3)
        self.d_plugin = tk.StringVar()
        ttk.Entry(f, textvariable=self.d_plugin, width=30).grid(row=r, column=1, sticky="w", padx=4, pady=3)
        ttk.Label(f, text="(optional, default: wp2custom_<hex>)").grid(row=r, column=2, sticky="w", padx=4)

        r += 1
        f2 = tk.Frame(f, bg="#1e1e2e")
        f2.grid(row=r, column=0, columnspan=3, sticky="w", padx=4, pady=3)
        self.d_autodetect = tk.BooleanVar(value=True)
        ttk.Checkbutton(f2, text="-D  Auto-detect HTTPS", variable=self.d_autodetect).pack(side="left", padx=(0, 12))
        ttk.Label(f2, text="Threads:").pack(side="left", padx=(0, 4))
        self.d_threads = tk.StringVar(value="10")
        ttk.Entry(f2, textvariable=self.d_threads, width=5).pack(side="left", padx=(0, 12))
        ttk.Label(f2, text="Timeout:").pack(side="left", padx=(0, 4))
        self.d_timeout = tk.StringVar(value="120")
        ttk.Entry(f2, textvariable=self.d_timeout, width=6).pack(side="left")

        r += 1
        self.d_verbose = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="-v  Verbose", variable=self.d_verbose).grid(row=r, column=1, sticky="w", padx=4, pady=3)

        r += 1
        hint = ttk.Label(f, text='Accepts lines like: https://target.co.th [wp2shell] sqli=timing proof=db ver=7.0',
                         foreground="#6c7086")
        hint.grid(row=r, column=0, columnspan=3, sticky="w", padx=4, pady=(6, 0))

        f.columnconfigure(1, weight=1)

    # ── Helpers ───────────────────────────────────────────────────────
    def _browse_file(self, var: tk.StringVar, label: str, pattern: str):
        path = filedialog.askopenfilename(filetypes=[(label, pattern), ("All", "*.*")])
        if path:
            var.set(path)

    def _append_log(self, msg: str):
        self.log.configure(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    # ── Build command ─────────────────────────────────────────────────
    def _active_tab(self) -> str:
        notebook = self.nametowidget("!notebook")
        active = notebook.select()
        if active == str(self.tab_single):
            return "single"
        if active == str(self.tab_deploy):
            return "deploy"
        return "mass"

    def _build_cmd(self) -> list[str] | None:
        tab = self._active_tab()
        if tab == "single":
            return self._build_single_cmd()
        if tab == "deploy":
            return self._build_deploy_cmd()
        return self._build_mass_cmd()

    def _build_single_cmd(self) -> list[str] | None:
        url = self.s_url.get().strip()
        if not url:
            messagebox.showwarning("Input error", "URL is required")
            return None
        argv = [sys.executable, WP2SHELL, "shell", url]
        php = self.s_php.get().strip()
        if php:
            argv += ["--upload-php", php]
            pname = self.s_plugin.get().strip()
            if pname:
                argv += ["--plugin-name", pname]
        if self.s_rce.get():
            argv.append("--rce")
        cmd = self.s_cmd.get().strip()
        if cmd and not self.s_rce.get():
            argv += ["--cmd", cmd]
        if self.s_interactive.get():
            argv.append("-i")
        return argv

    def _build_mass_cmd(self) -> list[str] | None:
        url = self.m_url.get().strip()
        listfile = self.m_list.get().strip()
        if not url and not listfile:
            messagebox.showwarning("Input error", "Enter a URL or select a target list")
            return None
        argv = [sys.executable, WP2SHELL_SCAN]
        if listfile:
            argv += ["-l", listfile]
        if url:
            argv += ["-u", url]
        if self.m_autodetect.get():
            argv.append("-D")
        if self.m_rce.get():
            argv.append("--rce")
        php = self.m_php.get().strip()
        if php and self.m_upload.get():
            argv += ["--upload-php", php]
            pname = self.m_plugin.get().strip()
            if pname:
                argv += ["--plugin-name", pname]
        threads = self.m_threads.get().strip()
        if threads and threads != "10":
            argv += ["-t", threads]
        timeout = self.m_timeout.get().strip()
        if timeout and timeout != "120":
            argv += ["--timeout", timeout]
        if self.m_verbose.get():
            argv.append("-v")
        return argv

    def _build_deploy_cmd(self) -> list[str] | None:
        listfile = self.d_list.get().strip()
        if not listfile:
            messagebox.showwarning("Input error", "Select a target list file")
            return None
        php = self.d_php.get().strip()
        if not php:
            messagebox.showwarning("Input error", "Select a PHP file to upload")
            return None
        argv = [sys.executable, WP2SHELL_DEPLOY, "-l", listfile, "-p", php]
        pname = self.d_plugin.get().strip()
        if pname:
            argv += ["-n", pname]
        if self.d_autodetect.get():
            argv.append("-D")
        threads = self.d_threads.get().strip()
        if threads and threads != "10":
            argv += ["-t", threads]
        timeout = self.d_timeout.get().strip()
        if timeout and timeout != "120":
            argv += ["--timeout", timeout]
        if self.d_verbose.get():
            argv.append("-v")
        return argv

    # ── Run / Stop ────────────────────────────────────────────────────
    def _run(self):
        if self._proc is not None:
            return
        argv = self._build_cmd()
        if argv is None:
            return
        self._clear_log()
        self._append_log("$ " + " ".join(argv))
        self._append_log("\u2500" * 60)
        self.run_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        threading.Thread(target=self._worker, args=(argv,), daemon=True).start()

    def _worker(self, argv: list[str]):
        try:
            creationflags = 0
            if sys.platform == "win32":
                creationflags = subprocess.CREATE_NO_WINDOW
            self._proc = subprocess.Popen(
                argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, cwd=BASE_DIR, creationflags=creationflags,
            )
            assert self._proc.stdout is not None
            for line in self._proc.stdout:
                self.after(0, self._append_log, line.rstrip("\n"))
            self._proc.wait()
            rc = self._proc.returncode
            self.after(0, self._append_log, f"\n[exit code: {rc}]")
        except Exception as e:
            self.after(0, self._append_log, f"\n[error: {e}]")
        finally:
            self._proc = None
            self.after(0, self._done)

    def _done(self):
        self.run_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")

    def _stop(self):
        if self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass
            self._append_log("[*] Stopped.")


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
