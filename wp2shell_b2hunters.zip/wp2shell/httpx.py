import argparse
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

TIMEOUT = 5
THREADS = 100

headers = {
    "User-Agent": "Mozilla/5.0"
}


def check(host):
    host = host.strip()

    if not host:
        return None

    for scheme in ("https://", "http://"):
        url = scheme + host
        try:
            r = requests.get(
                url,
                timeout=TIMEOUT,
                headers=headers,
                verify=False,
                allow_redirects=True,
            )

            # anggap aktif jika mendapat respons HTTP
            if r.status_code:
                return url

        except requests.RequestException:
            pass

    return None


def main():
    parser = argparse.ArgumentParser(
        description="Simple HTTP/HTTPS Checker"
    )

    parser.add_argument(
        "-l",
        "--list",
        required=True,
        help="Input file"
    )

    parser.add_argument(
        "-o",
        "--output",
        default="result.txt",
        help="Output file"
    )

    parser.add_argument(
        "-t",
        "--threads",
        type=int,
        default=100,
        help="Threads (default: 100)"
    )

    args = parser.parse_args()

    with open(args.list, encoding="utf-8") as f:
        hosts = list(dict.fromkeys(
            line.strip() for line in f if line.strip()
        ))

    results = []

    with ThreadPoolExecutor(max_workers=args.threads) as executor:
        futures = [executor.submit(check, host) for host in hosts]

        for future in as_completed(futures):
            result = future.result()

            if result:
                print(f"[+] {result}")
                results.append(result)

    with open(args.output, "w", encoding="utf-8") as f:
        for url in sorted(results):
            f.write(url + "\n")

    print(f"\nFound {len(results)} active hosts.")
    print(f"Saved to {args.output}")


if __name__ == "__main__":
    main()